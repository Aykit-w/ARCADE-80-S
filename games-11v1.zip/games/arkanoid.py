import pygame
import common 

class RetroArkanoid(common.RetroGame):
    def __init__(self):
        super().__init__("ARKANOID", common.Colors.LIGHT_BLUE, show_lives=True, show_highscore=True)
        self.reset()
        
    def reset(self):
        self.paddle_x = common.SCREEN_WIDTH//2 - 50
        self.paddle_y = common.SCREEN_HEIGHT - 80
        self.paddle_width = 100
        self.ball_x = common.SCREEN_WIDTH//2
        self.ball_y = common.SCREEN_HEIGHT//2
        self.ball_dx = 4
        self.ball_dy = -4
        self.ball_radius = 6
        
        self.bricks = []
        colors = [common.Colors.RED, common.Colors.YELLOW, common.Colors.GREEN, common.Colors.BLUE, common.Colors.MAGENTA]
        for row in range(5):
            for col in range(10):
                brick_x = col * 90 + 50
                brick_y = row * 30 + 80
                self.bricks.append({
                    'rect': pygame.Rect(brick_x, brick_y, 80, 20),
                    'color': colors[row]
                })
        
        self.game_over = False
        self.score = 0
        self.lives = 3
        
    def update(self):
        if self.game_over:
            return
            
        self.ball_x += self.ball_dx
        self.ball_y += self.ball_dy
        
        if self.ball_x <= self.ball_radius or self.ball_x >= common.SCREEN_WIDTH - self.ball_radius:
            self.ball_dx *= -1
        if self.ball_y <= 60:
            self.ball_dy *= -1
            
        paddle_rect = pygame.Rect(self.paddle_x, self.paddle_y, self.paddle_width, 15)
        ball_rect = pygame.Rect(self.ball_x - self.ball_radius, 
                               self.ball_y - self.ball_radius,
                               self.ball_radius*2, self.ball_radius*2)
        
        if ball_rect.colliderect(paddle_rect) and self.ball_dy > 0:
            self.ball_dy *= -1
            
        for brick in self.bricks[:]:
            if ball_rect.colliderect(brick['rect']):
                self.bricks.remove(brick)
                self.score += 10
                self.ball_dy *= -1
                break
                
        if self.ball_y >= common.SCREEN_HEIGHT:
            self.lives -= 1
            if self.lives <= 0:
                self.game_over = True
            else:
                self.ball_x, self.ball_y = common.SCREEN_WIDTH//2, common.SCREEN_HEIGHT//2
                self.ball_dx, self.ball_dy = 4, -4
                
        if len(self.bricks) == 0:
            self.game_over = True
    
    def draw(self):
        common.screen.fill(common.Colors.BLACK)
        
        for brick in self.bricks:
            pygame.draw.rect(common.screen, brick['color'], brick['rect'])
            for i in range(0, brick['rect'].width, 4):
                pygame.draw.line(common.screen, common.Colors.WHITE, 
                               (brick['rect'].x + i, brick['rect'].y),
                               (brick['rect'].x + i, brick['rect'].y + brick['rect'].height), 1)
            pygame.draw.rect(common.screen, common.Colors.WHITE, brick['rect'], 2)
        
        pygame.draw.rect(common.screen, common.Colors.LIGHT_CYAN, 
                        (self.paddle_x, self.paddle_y, self.paddle_width, 15))
        pygame.draw.rect(common.screen, common.Colors.WHITE, 
                        (self.paddle_x, self.paddle_y, self.paddle_width, 15), 2)
        
        pygame.draw.circle(common.screen, common.Colors.WHITE, (int(self.ball_x), int(self.ball_y)), self.ball_radius)
        pygame.draw.circle(common.screen, common.Colors.YELLOW, (int(self.ball_x), int(self.ball_y)), self.ball_radius-2)
        
        self.draw_hud()
        
        if self.game_over:
            self.draw_game_over()
        
        common.RetroEffects.draw_scanlines(common.screen)
    
    def handle_input(self, event):
        result = super().handle_input(event)
        if result: return result
        
        if event.type == pygame.MOUSEMOTION and not self.game_over:
            mouse_x, _ = event.pos
            self.paddle_x = max(0, min(mouse_x - self.paddle_width//2, 
                                      common.SCREEN_WIDTH - self.paddle_width))