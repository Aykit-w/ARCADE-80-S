import pygame
import random
import math
import common 

class RetroClicker(common.RetroGame):
    def __init__(self):
        super().__init__("КЛИКЕР", common.Colors.LIGHT_BLUE, show_lives=True, show_highscore=True)
        self.reset()
        
    def reset(self):
        self.score = 0
        self.time_left = 30
        self.last_time = pygame.time.get_ticks()
        self.game_over = False
        self.targets = []
        self.spawn_timer = 0
        
    def spawn_target(self):
        self.targets.append({
            'x': random.randint(100, common.SCREEN_WIDTH-100),
            'y': random.randint(100, common.SCREEN_HEIGHT-100),
            'radius': 30,
            'life': 60
        })
    
    def update(self):
        if self.game_over:
            return
        
        current_time = pygame.time.get_ticks()
        if current_time - self.last_time >= 1000:
            self.time_left -= 1
            self.last_time = current_time
            if self.time_left <= 0:
                self.game_over = True
        
        self.spawn_timer += 1
        if self.spawn_timer >= 30:
            self.spawn_target()
            self.spawn_timer = 0
        
        for target in self.targets[:]:
            target['life'] -= 1
            if target['life'] <= 0:
                self.targets.remove(target)
    
    def draw(self):
        common.screen.fill(common.Colors.BLACK)
        
        for target in self.targets:
            alpha = int(255 * (target['life'] / 60))
            pygame.draw.circle(common.screen, common.Colors.RED, (target['x'], target['y']), target['radius'])
            pygame.draw.circle(common.screen, common.Colors.WHITE, (target['x'], target['y']), target['radius'], 2)
            pygame.draw.circle(common.screen, common.Colors.YELLOW, (target['x'], target['y']), 5)
        
        score_text = common.font_large.render(str(self.score), True, common.Colors.YELLOW)
        score_rect = score_text.get_rect(center=(common.SCREEN_WIDTH//2, common.SCREEN_HEIGHT//2))
        common.screen.blit(score_text, score_rect)
        
        time_text = common.font_medium.render(f"TIME: {self.time_left}", True, common.Colors.CYAN)
        common.screen.blit(time_text, (common.SCREEN_WIDTH//2 - 50, 150))
        
        self.draw_hud()
        
        if self.game_over:
            self.draw_game_over()
        
        common.RetroEffects.draw_scanlines(common.screen)
    
    def handle_input(self, event):
        result = super().handle_input(event)
        if result: return result
        
        if event.type == pygame.MOUSEBUTTONDOWN and not self.game_over:
            mouse_x, mouse_y = event.pos
            for target in self.targets[:]:
                dist = math.sqrt((mouse_x - target['x'])**2 + (mouse_y - target['y'])**2)
                if dist <= target['radius']:
                    self.targets.remove(target)
                    self.score += 10
                    break