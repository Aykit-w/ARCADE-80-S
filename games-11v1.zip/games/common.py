# common.py (полный файл с изменениями)

import pygame
import random
import math

# Инициализация Pygame (вызывается в main)
pygame.init()

SCREEN_WIDTH = 1024
SCREEN_HEIGHT = 768
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
clock = pygame.time.Clock()

# Шрифты (загружаются в main)
font_large = None
font_medium = None
font_small = None

def init_fonts():
    global font_large, font_medium, font_small
    try:
        font_large = pygame.font.Font("PressStart2P.ttf", 32)
        font_medium = pygame.font.Font("PressStart2P.ttf", 20)
        font_small = pygame.font.Font("PressStart2P.ttf", 12)
    except:
        print("Ретро-шрифт не найден, используем системный")
        font_large = pygame.font.Font(None, 48)
        font_medium = pygame.font.Font(None, 32)
        font_small = pygame.font.Font(None, 20)

# Цвета CGA/EGA
class Colors:
    BLACK = (0, 0, 0)
    BLUE = (0, 0, 170)
    GREEN = (0, 170, 0)
    CYAN = (0, 170, 170)
    RED = (170, 0, 0)
    MAGENTA = (170, 0, 170)
    BROWN = (170, 85, 0)
    LIGHT_GRAY = (170, 170, 170)
    DARK_GRAY = (85, 85, 85)
    LIGHT_BLUE = (85, 85, 255)
    LIGHT_GREEN = (85, 255, 85)
    LIGHT_CYAN = (85, 255, 255)
    LIGHT_RED = (255, 85, 85)
    LIGHT_MAGENTA = (255, 85, 255)
    YELLOW = (255, 255, 85)
    WHITE = (255, 255, 255)

# Ретро-эффекты
class RetroEffects:
    @staticmethod
    def draw_scanlines(surface):
        scanline = pygame.Surface((SCREEN_WIDTH, 2))
        scanline.set_alpha(30)
        scanline.fill(Colors.BLACK)
        for y in range(0, SCREEN_HEIGHT, 4):
            surface.blit(scanline, (0, y))
    
    @staticmethod
    def draw_crt_corner(surface):
        for x in range(0, SCREEN_WIDTH, 2):
            for y in range(0, SCREEN_HEIGHT, 2):
                dist = math.sqrt((x - SCREEN_WIDTH//2)**2 + (y - SCREEN_HEIGHT//2)**2)
                if dist > 400:
                    alpha = min(255, int((dist - 400) / 2))
                    dark = pygame.Surface((2, 2))
                    dark.set_alpha(alpha)
                    dark.fill(Colors.BLACK)
                    surface.blit(dark, (x, y))

# Космический фон
class SpaceBackground:
    def __init__(self):
        self.stars = []
        for _ in range(200):
            self.stars.append({
                'x': random.randint(0, SCREEN_WIDTH),
                'y': random.randint(0, SCREEN_HEIGHT),
                'size': random.choice([1, 1, 1, 2]),
                'brightness': random.randint(100, 255)
            })
    
    def draw(self, surface):
        surface.fill(Colors.BLACK)
        for star in self.stars:
            brightness = star['brightness']
            pygame.draw.circle(surface, (brightness, brightness, brightness), 
                             (star['x'], star['y']), star['size'])

# Базовый класс игры - ИСПРАВЛЕННАЯ ВЕРСИЯ
class RetroGame:
    def __init__(self, name, color, show_lives=True, show_highscore=True):
        """
        Параметры:
        name - название игры
        color - цвет
        show_lives - показывать ли жизни (по умолчанию True)
        show_highscore - показывать ли рекорд (по умолчанию True)
        """
        self.name = name
        self.color = color
        self.show_lives = show_lives
        self.show_highscore = show_highscore
        
        self.score = 0
        self.lives = 3
        self.game_over = False
        
        # Рекорд загружается только если нужно
        self.high_score = 0
        if show_highscore:
            self.high_score = self.load_high_score()
    
    def load_high_score(self):
        """Загружает рекорд для этой игры из файла."""
        try:
            with open(f"{self.name.lower().replace(' ', '_')}_highscore.txt", "r") as f:
                return int(f.read())
        except:
            return 0
    
    def save_high_score(self):
        """Сохраняет рекорд только если рекорды включены"""
        if self.show_highscore and self.score > self.high_score:
            self.high_score = self.score
            try:
                with open(f"{self.name.lower().replace(' ', '_')}_highscore.txt", "w") as f:
                    f.write(str(self.high_score))
            except:
                pass
    
    def draw_hud(self):
        """Рисует интерфейс игрока (HUD)"""
        pygame.draw.rect(screen, Colors.BLACK, (0, 0, SCREEN_WIDTH, 60))
        pygame.draw.line(screen, self.color, (0, 60), (SCREEN_WIDTH, 60), 2)
        
        # Название игры (всегда)
        title = font_medium.render(self.name, True, self.color)
        screen.blit(title, (20, 20))
        
        # Счет (всегда)
        score_text = font_small.render(f"SCORE {self.score:06d}", True, Colors.YELLOW)
        screen.blit(score_text, (300, 25))
        
        # Рекорд (только если нужно)
        x_position = 550
        if self.show_highscore:
            high_text = font_small.render(f"HISCORE {self.high_score:06d}", True, Colors.LIGHT_RED)
            screen.blit(high_text, (x_position, 25))
            x_position += 250
        
        # Жизни (только если нужно)
        if self.show_lives:
            lives_text = font_small.render(f"LIVES {self.lives}", True, Colors.LIGHT_GREEN)
            screen.blit(lives_text, (x_position, 25))
        
        pygame.draw.line(screen, self.color, (0, SCREEN_HEIGHT-30), 
                        (SCREEN_WIDTH, SCREEN_HEIGHT-30), 2)
        help_text = font_small.render("PRESS ESC FOR MENU/управлять на стрелочки", True, Colors.LIGHT_GRAY)
        screen.blit(help_text, (20, SCREEN_HEIGHT-25))
    
    def draw_game_over(self):
        """Рисует поверхность 'Game Over' и проверяет, не установлен ли новый рекорд."""
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(180)
        overlay.fill(Colors.BLACK)
        screen.blit(overlay, (0, 0))
        
        if (pygame.time.get_ticks() // 500) % 2:
            game_over = font_large.render("GAME OVER", True, Colors.RED)
            text_rect = game_over.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2))
            screen.blit(game_over, text_rect)
        
        if self.show_highscore and self.score > self.high_score:
            self.save_high_score()
            new_record = font_medium.render("NEW RECORD!", True, Colors.YELLOW)
            record_rect = new_record.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2 + 50))
            screen.blit(new_record, record_rect)
    
    def handle_input(self, event):
        """Обрабатывает общие для всех игр команды: ESC для выхода в меню, R для рестарта."""
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                return "menu"
            if event.key == pygame.K_r:
                self.reset()
        return None