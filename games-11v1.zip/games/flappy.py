import pygame
import random
import common

class RetroFlappyBird(common.RetroGame):
    def __init__(self):
        super().__init__("ФЛЕПЕ БИРД", common.Colors.LIGHT_BLUE, show_lives=False, show_highscore=True)
        self.reset()
        
    def reset(self):
        self.bird_x = 200
        self.bird_y = common.SCREEN_HEIGHT//2
        self.bird_radius = 15
        self.bird_vy = 0
        self.gravity = 0.5
        self.jump = -10
        
        self.pipes = []
        self.pipe_width = 60
        self.pipe_gap = 200
        self.pipe_speed = 4
        self.spawn_timer = 0
        
        self.score = 0
        self.game_over = False
        
    def spawn_pipe(self):
        gap_y = random.randint(150, common.SCREEN_HEIGHT - 150 - self.pipe_gap)
        self.pipes.append({
            'x': common.SCREEN_WIDTH,
            'gap_y': gap_y,
            'passed': False
        })
    
    def update(self):
        if self.game_over:
            return
        
        self.bird_vy += self.gravity
        self.bird_y += self.bird_vy
        
        if self.bird_y <= 60 or self.bird_y >= common.SCREEN_HEIGHT - 30:
            self.game_over = True
        
        self.spawn_timer += 1
        if self.spawn_timer >= 90:
            self.spawn_pipe()
            self.spawn_timer = 0
        
        bird_rect = pygame.Rect(self.bird_x - self.bird_radius,
                               self.bird_y - self.bird_radius,
                               self.bird_radius*2, self.bird_radius*2)
        
        for pipe in self.pipes[:]:
            pipe['x'] -= self.pipe_speed
            
            top_pipe = pygame.Rect(pipe['x'], 60, self.pipe_width, pipe['gap_y'] - 60)
            bottom_pipe = pygame.Rect(pipe['x'], pipe['gap_y'] + self.pipe_gap,
                                     self.pipe_width, common.SCREEN_HEIGHT - pipe['gap_y'] - self.pipe_gap - 30)
            
            if bird_rect.colliderect(top_pipe) or bird_rect.colliderect(bottom_pipe):
                self.game_over = True
            
            if not pipe['passed'] and pipe['x'] + self.pipe_width < self.bird_x:
                pipe['passed'] = True
                self.score += 10
            
            if pipe['x'] + self.pipe_width < 0:
                self.pipes.remove(pipe)
    
    def draw(self):
        common.screen.fill(common.Colors.BLACK)
        
        for pipe in self.pipes:
            pygame.draw.rect(common.screen, common.Colors.GREEN, (pipe['x'], 60, self.pipe_width, pipe['gap_y'] - 60))
            pygame.draw.rect(common.screen, common.Colors.LIGHT_GREEN, (pipe['x'], pipe['gap_y'] - 30, self.pipe_width, 30))
            
            pygame.draw.rect(common.screen, common.Colors.GREEN, 
                           (pipe['x'], pipe['gap_y'] + self.pipe_gap,
                            self.pipe_width, common.SCREEN_HEIGHT - pipe['gap_y'] - self.pipe_gap - 30))
            pygame.draw.rect(common.screen, common.Colors.LIGHT_GREEN,
                           (pipe['x'], pipe['gap_y'] + self.pipe_gap,
                            self.pipe_width, 30))
        
        pygame.draw.circle(common.screen, common.Colors.YELLOW, (self.bird_x, int(self.bird_y)), self.bird_radius)
        pygame.draw.circle(common.screen, common.Colors.BLACK, (self.bird_x + 5, int(self.bird_y) - 5), 3)
        
        if (pygame.time.get_ticks() // 200) % 2:
            pygame.draw.ellipse(common.screen, common.Colors.YELLOW, 
                              (self.bird_x - 20, self.bird_y - 5, 15, 10))
        
        self.draw_hud()
        
        if self.game_over:
            self.draw_game_over()
        
        common.RetroEffects.draw_scanlines(common.screen)
    
    def handle_input(self, event):
        result = super().handle_input(event)
        if result: return result
        
        if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE and not self.game_over:
            self.bird_vy = self.jump