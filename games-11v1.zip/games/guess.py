import pygame
import random
import common

class RetroGuessNumber(common.RetroGame):
    def __init__(self):
        super().__init__("УГОДАЙ ЧИСЛО", common.Colors.LIGHT_BLUE, show_lives=False, show_highscore=False)
        self.reset()
        
    def reset(self):
        self.secret = random.randint(1, 100)
        self.guess = ""
        self.message = "ENTER NUMBER 1-100"
        self.attempts = 0
        self.game_over = False
        self.won = False
        
    def update(self):
        pass
    
    def draw(self):
        common.screen.fill(common.Colors.BLACK)
        
        title = common.font_medium.render("GUESS THE NUMBER", True, self.color)
        title_rect = title.get_rect(center=(common.SCREEN_WIDTH//2, 150))
        common.screen.blit(title, title_rect)
        
        msg_text = common.font_medium.render(self.message, True, common.Colors.YELLOW)
        msg_rect = msg_text.get_rect(center=(common.SCREEN_WIDTH//2, 250))
        common.screen.blit(msg_text, msg_rect)
        
        if not self.won and not self.game_over:
            guess_text = common.font_large.render(self.guess, True, common.Colors.CYAN)
            guess_rect = guess_text.get_rect(center=(common.SCREEN_WIDTH//2, 350))
            common.screen.blit(guess_text, guess_rect)
            
            pygame.draw.rect(common.screen, common.Colors.CYAN, 
                           (guess_rect.x - 10, guess_rect.y - 10, 
                            guess_rect.width + 20, guess_rect.height + 20), 2)
        
        attempts_text = common.font_small.render(f"ATTEMPTS: {self.attempts}", True, common.Colors.LIGHT_GRAY)
        common.screen.blit(attempts_text, (50, 450))
        
        if self.won:
            win_text = common.font_large.render(f"WIN! {self.secret}", True, common.Colors.GREEN)
            win_rect = win_text.get_rect(center=(common.SCREEN_WIDTH//2, 500))
            common.screen.blit(win_text, win_rect)
        
        self.draw_hud()
        common.RetroEffects.draw_scanlines(common.screen)
    
    def handle_input(self, event):
        result = super().handle_input(event)
        if result: return result
        
        if event.type == pygame.KEYDOWN and not self.won and not self.game_over:
            if event.key == pygame.K_RETURN and self.guess:
                try:
                    num = int(self.guess)
                    self.attempts += 1
                    if num < self.secret:
                        self.message = "TOO LOW"
                    elif num > self.secret:
                        self.message = "TOO HIGH"
                    else:
                        self.message = f"CORRECT! {self.attempts} ATTEMPTS"
                        self.won = True
                        self.score += max(0, 1000 - self.attempts * 10)
                    self.guess = ""
                except:
                    self.message = "INVALID INPUT"
            elif event.key == pygame.K_BACKSPACE:
                self.guess = self.guess[:-1]
            elif event.unicode.isdigit():
                self.guess += event.unicode