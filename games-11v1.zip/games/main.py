import pygame
import sys
import math
import common 
from snake import RetroSnake
from arkanoid import RetroArkanoid
from maze import RetroMaze
from pong import RetroPong
from guess import RetroGuessNumber
from clicker import RetroClicker
from shooter import RetroShootingGallery
from racing import RetroRacing
from tetris import RetroTetris
from flappy import RetroFlappyBird
from tictactoe import RetroTicTacToe

# Инициализация шрифтов
common.init_fonts()
pygame.display.set_caption("RETRO ARCADE COLLECTION '80s")

class RetroMenu:
    def __init__(self):
        self.games = [
            ("01  SNAKE", common.Colors.GREEN, RetroSnake),
            ("02  ARKANOID", common.Colors.LIGHT_BLUE, RetroArkanoid),
            ("03  MAZE", common.Colors.YELLOW, RetroMaze),
            ("04  PONG", common.Colors.LIGHT_CYAN, RetroPong),
            ("05  GUESS NUMBER", common.Colors.LIGHT_MAGENTA, RetroGuessNumber),
            ("06  CLICKER", common.Colors.LIGHT_RED, RetroClicker),
            ("07  SHOOTING GALLERY", common.Colors.LIGHT_GREEN, RetroShootingGallery),
            ("08  RACING", common.Colors.LIGHT_RED, RetroRacing),
            ("09  TETRIS", common.Colors.LIGHT_CYAN, RetroTetris),
            ("10  FLAPPY BIRD", common.Colors.YELLOW, RetroFlappyBird),
            ("11  TIC TAC TOE", common.Colors.LIGHT_MAGENTA, RetroTicTacToe),
            ("12  EXIT", common.Colors.RED, None)
        ]
        self.selected = 0
        self.space_bg = common.SpaceBackground()
        
    def draw(self):
        self.space_bg.draw(common.screen)
        
        pygame.draw.rect(common.screen, common.Colors.YELLOW, (20, 20, common.SCREEN_WIDTH-40, common.SCREEN_HEIGHT-40), 3)
        pygame.draw.rect(common.screen, common.Colors.LIGHT_GRAY, (25, 25, common.SCREEN_WIDTH-50,common.SCREEN_HEIGHT-50), 1)
        
        title_shadow = common.font_large.render("ARCADE 80's", True, common.Colors.DARK_GRAY)
        title = common.font_large.render("ARCADE 80's", True, common.Colors.YELLOW)
        title_rect = title.get_rect(center=(common.SCREEN_WIDTH//2, 70))
        common.screen.blit(title_shadow, (title_rect.x + 3, title_rect.y + 3))
        common.screen.blit(title, title_rect)
        
        start_y = 150
        for i, (game_name, color, _) in enumerate(self.games):
            y = start_y + i * 40
            
            if i == self.selected:
                pulse = int(50 * math.sin(pygame.time.get_ticks() / 200))
                glow_color = (
                    max(0, min(255, color[0] + pulse)),
                    max(0, min(255, color[1] + pulse)),
                    max(0, min(255, color[2] + pulse))
                )
                pygame.draw.rect(common.screen, glow_color, (200, y-10, common.SCREEN_WIDTH-400, 35), 3)
                pygame.draw.polygon(common.screen, common.Colors.YELLOW, 
                                   [(180, y), (160, y-5), (160, y+5)])
            
            num_text = common.font_medium.render(f"{i+1:02d}", True, common.Colors.LIGHT_GRAY)
            common.screen.blit(num_text, (250, y))
            name_text = common.font_medium.render(game_name, True, color)
            common.screen.blit(name_text, (350, y))
        
        inst_y = common.SCREEN_HEIGHT - 80
        pygame.draw.rect(common.screen, common.Colors.BLUE, (50, inst_y-10, common.SCREEN_WIDTH-100, 40))
        pygame.draw.rect(common.screen, common.Colors.WHITE, (50, inst_y-10, common.SCREEN_WIDTH-100, 40), 2)
        
        inst1 = common.font_small.render("UP/DOWN SELECT", True, common.Colors.WHITE)
        inst2 = common.font_small.render("ENTER START", True, common.Colors.WHITE)
        inst3 = common.font_small.render("ESC QUIT", True, common.Colors.WHITE)
        
        common.screen.blit(inst1, (150, inst_y))
        common.screen.blit(inst2, (400, inst_y))
        common.screen.blit(inst3, (650, inst_y))
        
        common.RetroEffects.draw_scanlines(common.screen)
        common.RetroEffects.draw_crt_corner(common.screen)
    
    def handle_input(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                self.selected = (self.selected - 1) % len(self.games)
            elif event.key == pygame.K_DOWN:
                self.selected = (self.selected + 1) % len(self.games)
            elif event.key == pygame.K_RETURN:
                return self.selected
        return None

class RetroArcade:
    def __init__(self):
        self.menu = RetroMenu()
        self.current_game = None
        self.running = True
        
    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                
                if self.current_game:
                    result = self.current_game.handle_input(event)
                    if result == "menu":
                        self.current_game = None
                else:
                    result = self.menu.handle_input(event)
                    if result is not None:
                        if result == 11:  # Exit
                            self.running = False
                        else:
                            game_class = self.menu.games[result][2]
                            if game_class:
                                self.current_game = game_class()
            
            if self.current_game:
                self.current_game.update()
                self.current_game.draw()
            else:
                self.menu.draw()
            
            pygame.display.flip()
            common.clock.tick(60)
        
        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    game = RetroArcade()
    game.run()