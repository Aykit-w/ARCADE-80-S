import pygame
import random
import common

class RetroMaze(common.RetroGame):
    def __init__(self):
        super().__init__("ЛАБИРИНТ", common.Colors.LIGHT_BLUE, show_lives=False, show_highscore=False)
        self.cell_size = 30
        self.grid_width = common.SCREEN_WIDTH // self.cell_size
        self.grid_height = (common.SCREEN_HEIGHT - 100) // self.cell_size
        self.generate_maze()
        self.reset()
        
    def generate_maze(self):
        self.exit_x = self.grid_width - 3
        self.exit_y = self.grid_height - 2
        
        self.maze = [[1 for _ in range(self.grid_width)] for _ in range(self.grid_height)]
        stack = [(1, 2)]
        self.maze[1][2] = 0
        
        while stack:
            x, y = stack[-1]
            neighbors = []
            for dx, dy in [(2,0), (-2,0), (0,2), (0,-2)]:
                nx, ny = x + dx, y + dy
                if 0 < nx < self.grid_width-1 and 1 < ny < self.grid_height-1 and self.maze[ny][nx] == 1:
                    neighbors.append((nx, ny, dx//2, dy//2))
            
            if neighbors:
                nx, ny, wx, wy = random.choice(neighbors)
                self.maze[ny][nx] = 0
                self.maze[y + wy][x + wx] = 0
                stack.append((nx, ny))
            else:
                stack.pop()
        
        self.maze[self.exit_y][self.exit_x] = 2
        
    def reset(self):
        self.player_x = 1
        self.player_y = 2
        self.game_over = False
        self.won = False
        self.score = 0
        self.moves = 0
    
    def update(self):
        if self.won or self.game_over:
            return
    
    def draw(self):
        common.screen.fill(common.Colors.BLACK)
        
        for y in range(self.grid_height):
            for x in range(self.grid_width):
                if self.maze[y][x] == 1:
                    rect = pygame.Rect(x*self.cell_size, y*self.cell_size + 60,
                                      self.cell_size-2, self.cell_size-2)
                    pygame.draw.rect(common.screen, common.Colors.BLUE, rect)
                    pygame.draw.rect(common.screen, common.Colors.LIGHT_BLUE, rect, 1)
                elif self.maze[y][x] == 2:
                    rect = pygame.Rect(x*self.cell_size, y*self.cell_size + 60,
                                      self.cell_size-2, self.cell_size-2)
                    pygame.draw.rect(common.screen, common.Colors.GREEN, rect)
                    star_x = rect.x + rect.width//2
                    star_y = rect.y + rect.height//2
                    pygame.draw.circle(common.screen, common.Colors.YELLOW, (star_x, star_y), 5)
        
        player_rect = pygame.Rect(self.player_x*self.cell_size, self.player_y*self.cell_size + 60,
                                 self.cell_size-2, self.cell_size-2)
        pygame.draw.rect(common.screen, common.Colors.RED, player_rect)
        pygame.draw.circle(common.screen, common.Colors.WHITE, (player_rect.x + 5, player_rect.y + 5), 2)
        pygame.draw.circle(common.screen, common.Colors.WHITE, (player_rect.x + 15, player_rect.y + 5), 2)
        
        self.draw_hud()
        
        if self.won:
            self.draw_win()
        elif self.game_over:
            self.draw_game_over()
        
        common.RetroEffects.draw_scanlines(common.screen)
    
    def draw_win(self):
        overlay = pygame.Surface((common.SCREEN_WIDTH, common.SCREEN_HEIGHT))
        overlay.set_alpha(180)
        overlay.fill(common.Colors.BLACK)
        common.screen.blit(overlay, (0, 0))
        
        win_text = common.font_large.render("YOU ESCAPED!", True, common.Colors.GREEN)
        text_rect = win_text.get_rect(center=(common.SCREEN_WIDTH//2, common.SCREEN_HEIGHT//2))
        common.screen.blit(win_text, text_rect)
    
    def handle_input(self, event):
        result = super().handle_input(event)
        if result: return result
        
        if event.type == pygame.KEYDOWN and not self.won and not self.game_over:
            new_x, new_y = self.player_x, self.player_y
            if event.key == pygame.K_UP:
                new_y -= 1
            elif event.key == pygame.K_DOWN:
                new_y += 1
            elif event.key == pygame.K_LEFT:
                new_x -= 1
            elif event.key == pygame.K_RIGHT:
                new_x += 1
            
            if (0 <= new_x < self.grid_width and 0 <= new_y < self.grid_height and
                self.maze[new_y][new_x] != 1):
                self.player_x, self.player_y = new_x, new_y
                self.moves += 1
                if self.maze[new_y][new_x] == 2:
                    self.won = True
                    self.score += 1000 - self.moves * 10