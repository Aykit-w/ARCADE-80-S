import pygame
import random
import common 

class RetroPong(common.RetroGame):
    def __init__(self):
        super().__init__("ПИН-ПОНГ", common.Colors.LIGHT_BLUE, show_lives=False, show_highscore=True)
        self.reset()
        
    def reset(self):
        self.paddle_width = 15
        self.paddle_height = 100
        self.left_paddle = common.SCREEN_HEIGHT//2 - self.paddle_height//2
        self.right_paddle = common.SCREEN_HEIGHT//2 - self.paddle_height//2
        
        self.ball_size = 10
        self.ball_x = common.SCREEN_WIDTH//2
        self.ball_y = common.SCREEN_HEIGHT//2
        self.ball_dx = random.choice([-5, 5])
        self.ball_dy = random.uniform(-3, 3)
        
        self.left_score = 0
        self.right_score = 0
        self.game_over = False
        
    def update(self):
        if self.game_over:
            return
            
        self.ball_x += self.ball_dx
        self.ball_y += self.ball_dy
        
        if self.ball_y <= 60 or self.ball_y >= common.SCREEN_HEIGHT - 30 - self.ball_size:
            self.ball_dy *= -1
        
        left_rect = pygame.Rect(50, self.left_paddle, self.paddle_width, self.paddle_height)
        right_rect = pygame.Rect(common.SCREEN_WIDTH - 50 - self.paddle_width, self.right_paddle,
                                self.paddle_width, self.paddle_height)
        ball_rect = pygame.Rect(self.ball_x, self.ball_y, self.ball_size, self.ball_size)
        
        if ball_rect.colliderect(left_rect) and self.ball_dx < 0:
            self.ball_dx = abs(self.ball_dx)
            offset = (self.ball_y + self.ball_size/2) - (self.left_paddle + self.paddle_height/2)
            self.ball_dy = offset / (self.paddle_height/2) * 7
            
        if ball_rect.colliderect(right_rect) and self.ball_dx > 0:
            self.ball_dx = -abs(self.ball_dx)
            offset = (self.ball_y + self.ball_size/2) - (self.right_paddle + self.paddle_height/2)
            self.ball_dy = offset / (self.paddle_height/2) * 7
        
        if self.ball_x <= 0:
            self.right_score += 1
            self.reset_ball()
        elif self.ball_x >= common.SCREEN_WIDTH - self.ball_size:
            self.left_score += 1
            self.reset_ball()
        
        target_y = self.ball_y - self.paddle_height/2
        self.right_paddle += (target_y - self.right_paddle) * 0.1
        self.right_paddle = max(60, min(self.right_paddle, common.SCREEN_HEIGHT - 30 - self.paddle_height))
    
    def reset_ball(self):
        self.ball_x = common.SCREEN_WIDTH//2
        self.ball_y = common.SCREEN_HEIGHT//2
        self.ball_dx = random.choice([-5, 5])
        self.ball_dy = random.uniform(-3, 3)
    
    def draw(self):
        common.screen.fill(common.Colors.BLACK)
        
        pygame.draw.line(common.screen, common.Colors.WHITE, (common.SCREEN_WIDTH//2, 60), 
                        (common.SCREEN_WIDTH//2, common.SCREEN_HEIGHT-30), 2)
        
        pygame.draw.rect(common.screen, common.Colors.WHITE, (50, self.left_paddle, self.paddle_width, self.paddle_height))
        pygame.draw.rect(common.screen, common.Colors.WHITE, (common.SCREEN_WIDTH-50-self.paddle_width, self.right_paddle,
                                               self.paddle_width, self.paddle_height))
        
        pygame.draw.rect(common.screen, common.Colors.YELLOW, (self.ball_x, self.ball_y, self.ball_size, self.ball_size))
        
        left_score_text = common.font_large.render(str(self.left_score), True, common.Colors.LIGHT_CYAN)
        right_score_text = common.font_large.render(str(self.right_score), True, common.Colors.LIGHT_CYAN)
        common.screen.blit(left_score_text, (common.SCREEN_WIDTH//2 - 100, 100))
        common.screen.blit(right_score_text, (common.SCREEN_WIDTH//2 + 50, 100))
        
        self.draw_hud()
        
        if self.game_over:
            self.draw_game_over()
        
        common.RetroEffects.draw_scanlines(common.screen)
    
    def handle_input(self, event):
        result = super().handle_input(event)
        if result: return result
        
        keys = pygame.key.get_pressed()
        if keys[pygame.K_w]:
            self.left_paddle -= 8
        if keys[pygame.K_s]:
            self.left_paddle += 8
        self.left_paddle = max(60, min(self.left_paddle, common.SCREEN_HEIGHT - 30 - self.paddle_height))