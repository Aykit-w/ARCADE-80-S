import pygame
import random
import common

class RetroRacing(common.RetroGame):
    def __init__(self):
        super().__init__("ШАШКИ", common.Colors.LIGHT_BLUE, show_lives=False, show_highscore=True)
        self.reset()
        
    def reset(self):
        self.car_x = common.SCREEN_WIDTH//2 - 20
        self.car_y = common.SCREEN_HEIGHT - 120
        self.car_width = 40
        self.car_height = 60
        
        self.obstacles = []
        self.spawn_timer = 0
        self.speed = 5
        self.score = 0
        self.game_over = False
        self.road_offset = 0
        
    def spawn_obstacle(self):
        x = random.randint(100, common.SCREEN_WIDTH - 100)
        self.obstacles.append({
            'rect': pygame.Rect(x, -50, 30, 50),
            'color': random.choice([common.Colors.RED,common. Colors.BLUE, common.Colors.YELLOW])
        })
    
    def update(self):
        if self.game_over:
            return
        
        self.spawn_timer += 1
        if self.spawn_timer >= 40:
            self.spawn_obstacle()
            self.spawn_timer = 0
        
        self.road_offset = (self.road_offset + self.speed) % 40
        
        for obstacle in self.obstacles[:]:
            obstacle['rect'].y += self.speed
            if obstacle['rect'].y > common.SCREEN_HEIGHT:
                self.obstacles.remove(obstacle)
                self.score += 10
        
        car_rect = pygame.Rect(self.car_x, self.car_y, self.car_width, self.car_height)
        for obstacle in self.obstacles:
            if car_rect.colliderect(obstacle['rect']):
                self.game_over = True
    
    def draw(self):
        common.screen.fill(common.Colors.BLACK)
        
        for i in range(0, common.SCREEN_WIDTH, 40):
            pygame.draw.line(common.screen, common.Colors.DARK_GRAY, (i, 60), (i, common.SCREEN_HEIGHT-30), 1)
        
        for i in range(0, common.SCREEN_HEIGHT-90, 40):
            y = i + self.road_offset + 60
            if y < common.SCREEN_HEIGHT-30:
                pygame.draw.line(common.screen, common.Colors.WHITE, (common.SCREEN_WIDTH//2 - 100, y),
                               (common.SCREEN_WIDTH//2 - 50, y), 2)
                pygame.draw.line(common.screen, common.Colors.WHITE, (common.SCREEN_WIDTH//2 + 50, y),
                               (common.SCREEN_WIDTH//2 + 100, y), 2)
        
        pygame.draw.rect(common.screen, common.Colors.LIGHT_BLUE, 
                        (self.car_x, self.car_y, self.car_width, self.car_height))
        pygame.draw.rect(common.screen, common.Colors.WHITE, 
                        (self.car_x + 5, self.car_y + 5, 10, 10))
        pygame.draw.rect(common.screen, common.Colors.WHITE, 
                        (self.car_x + 25, self.car_y + 5, 10, 10))
        
        for obstacle in self.obstacles:
            pygame.draw.rect(common.screen, obstacle['color'], obstacle['rect'])
        
        self.draw_hud()
        
        if self.game_over:
            self.draw_game_over()
        
        common.RetroEffects.draw_scanlines(common.screen)
    
    def handle_input(self, event):
        result = super().handle_input(event)
        if result: return result
        
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and self.car_x > 50:
            self.car_x -= 7
        if keys[pygame.K_RIGHT] and self.car_x < common.SCREEN_WIDTH - 50 - self.car_width:
            self.car_x += 7
        if keys[pygame.K_UP]:
            self.speed = min(self.speed + 0.1, 8)
        if keys[pygame.K_DOWN]:
            self.speed = max(self.speed - 0.1, 3)