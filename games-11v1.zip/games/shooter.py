import pygame
import random
import common

class RetroShootingGallery(common.RetroGame):
    def __init__(self):
        super().__init__("ТИР", common.Colors.LIGHT_BLUE, show_lives=True, show_highscore=True)
        self.reset()
        
    def reset(self):
        self.score = 0
        self.targets = []
        self.spawn_timer = 0
        self.game_over = False
        self.lives = 5
        self.ammo = 30
        
    def spawn_target(self):
        self.targets.append({
            'x': random.randint(50, common.SCREEN_WIDTH-50),
            'y': random.randint(80, common.SCREEN_HEIGHT-80),
            'vx': random.choice([-2, -1, 1, 2]),
            'vy': random.choice([-2, -1, 1, 2]),
            'size': random.randint(20, 40),
            'color': random.choice([common.Colors.RED, common.Colors.YELLOW, common.Colors.GREEN, common.Colors.BLUE])
        })
    
    def update(self):
        if self.game_over:
            return
        
        self.spawn_timer += 1
        if self.spawn_timer >= 45 and len(self.targets) < 8:
            self.spawn_target()
            self.spawn_timer = 0
        
        for target in self.targets[:]:
            target['x'] += target['vx']
            target['y'] += target['vy']
            
            if target['x'] <= 0 or target['x'] >= common.SCREEN_WIDTH:
                target['vx'] *= -1
            if target['y'] <= 60 or target['y'] >= common.SCREEN_HEIGHT-30:
                target['vy'] *= -1
    
    def draw(self):
        common.screen.fill(common.Colors.BLACK)
        
        for target in self.targets:
            pygame.draw.rect(common.screen, target['color'], 
                           (target['x'] - target['size']//2, target['y'] - target['size']//2,
                            target['size'], target['size']))
            pygame.draw.circle(common.screen, common.Colors.WHITE, (target['x'], target['y']), target['size']//3)
            pygame.draw.circle(common.screen, common.Colors.RED, (target['x'], target['y']), target['size']//6)
        
        ammo_text = common.font_small.render(f"AMMO: {self.ammo}", True, common.Colors.YELLOW)
        common.screen.blit(ammo_text, (50, 650))
        
        lives_text = common.font_small.render(f"LIVES: {self.lives}", True, common.Colors.RED)
        common.screen.blit(lives_text, (200, 650))
        
        self.draw_hud()
        
        if self.game_over:
            self.draw_game_over()
        
        common.RetroEffects.draw_scanlines(common.screen)
    
    def handle_input(self, event):
        result = super().handle_input(event)
        if result: return result
        
        if event.type == pygame.MOUSEBUTTONDOWN and not self.game_over:
            if self.ammo <= 0:
                return
            self.ammo -= 1
            mouse_x, mouse_y = event.pos
            hit = False
            for target in self.targets[:]:
                if (abs(mouse_x - target['x']) <= target['size']//2 and
                    abs(mouse_y - target['y']) <= target['size']//2):
                    self.targets.remove(target)
                    self.score += 50
                    hit = True
                    break
            if not hit:
                self.lives -= 1
                if self.lives <= 0:
                    self.game_over = True