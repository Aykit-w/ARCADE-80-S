import pygame
import random
import common 

class RetroSnake(common.RetroGame):
    def __init__(self):
        super().__init__("ЗМЕЯ", common.Colors.LIGHT_BLUE, show_lives=False, show_highscore=True)
        self.cell_size = 20
        self.grid_width = common.SCREEN_WIDTH // self.cell_size
        self.grid_height = (common.SCREEN_HEIGHT - 100) // self.cell_size
        self.reset()
        
    def reset(self):
        self.snake = [(self.grid_width//2, self.grid_height//2 + 3)]
        self.direction = (1, 0)
        self.food = self.generate_food()
        self.game_over = False
        self.score = 0
        
    def generate_food(self):
        while True:
            food = (random.randint(0, self.grid_width-1), 
                   random.randint(0, self.grid_height-1) + 3)
            if food not in self.snake:
                return food
    
    def update(self):
        if self.game_over:
            return
            
        head = self.snake[0]
        new_head = (head[0] + self.direction[0], head[1] + self.direction[1])
        
        if (new_head[0] < 0 or new_head[0] >= self.grid_width or
            new_head[1] < 3 or new_head[1] >= self.grid_height + 3 or
            new_head in self.snake):
            self.game_over = True
            return
            
        self.snake.insert(0, new_head)
        
        if new_head == self.food:
            self.score += 10
            self.food = self.generate_food()
        else:
            self.snake.pop()
    
    def draw(self):
        common.screen.fill(common.Colors.BLACK)
        
        for x in range(0, common.SCREEN_WIDTH, self.cell_size):
            pygame.draw.line(common.screen, common.Colors.DARK_GRAY, (x, 60), (x, common.SCREEN_HEIGHT-30), 1)
        for y in range(60, common.SCREEN_HEIGHT-30, self.cell_size):
            pygame.draw.line(common.screen, common.Colors.DARK_GRAY, (0, y), (common.SCREEN_WIDTH, y), 1)
        
        for i, segment in enumerate(self.snake):
            rect = pygame.Rect(segment[0]*self.cell_size, segment[1]*self.cell_size,
                             self.cell_size-2, self.cell_size-2)
            
            if i == 0:
                pygame.draw.rect(common.screen, common.Colors.LIGHT_GREEN, rect)
                eye_color = common.Colors.BLACK if (pygame.time.get_ticks() // 500) % 2 else common.Colors.WHITE
                if self.direction == (1, 0):
                    pygame.draw.circle(common.screen, eye_color, (rect.x + 15, rect.y + 5), 2)
                    pygame.draw.circle(common.screen, eye_color, (rect.x + 15, rect.y + 15), 2)
                elif self.direction == (-1, 0):
                    pygame.draw.circle(common.screen, eye_color, (rect.x + 5, rect.y + 5), 2)
                    pygame.draw.circle(common.screen, eye_color, (rect.x + 5, rect.y + 15), 2)
                else:
                    pygame.draw.circle(common.screen, eye_color, (rect.x + 5, rect.y + 10), 2)
                    pygame.draw.circle(common.screen, eye_color, (rect.x + 15, rect.y + 10), 2)
            else:
                pygame.draw.rect(common.screen, common.Colors.GREEN, rect)
            pygame.draw.rect(common.screen, common.Colors.WHITE, rect, 1)
        
        food_rect = pygame.Rect(self.food[0]*self.cell_size, self.food[1]*self.cell_size,
                               self.cell_size-2, self.cell_size-2)
        pygame.draw.rect(common.screen, common.Colors.RED, food_rect)
        pygame.draw.rect(common.screen, common.Colors.YELLOW, food_rect, 1)
        pygame.draw.circle(common.screen, common.Colors.GREEN, (food_rect.x + 15, food_rect.y - 3), 3)
        
        self.draw_hud()
        
        if self.game_over:
            self.draw_game_over()
        
        common.RetroEffects.draw_scanlines(common.screen)
    
    def handle_input(self, event):
        result = super().handle_input(event)
        if result: return result
        
        if event.type == pygame.KEYDOWN and not self.game_over:
            if event.key == pygame.K_UP and self.direction != (0, 1):
                self.direction = (0, -1)
            elif event.key == pygame.K_DOWN and self.direction != (0, -1):
                self.direction = (0, 1)
            elif event.key == pygame.K_LEFT and self.direction != (1, 0):
                self.direction = (-1, 0)
            elif event.key == pygame.K_RIGHT and self.direction != (-1, 0):
                self.direction = (1, 0)