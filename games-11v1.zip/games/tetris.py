import pygame
import random
import common 

class RetroTetris(common.RetroGame):
    def __init__(self):
        super().__init__("ТЕТРИС", common.Colors.LIGHT_BLUE, show_lives=False, show_highscore=True)
        self.cell_size = 30
        self.grid_width = 10
        self.grid_height = 20
        self.grid_x = (common.SCREEN_WIDTH - self.cell_size * self.grid_width) // 2
        self.grid_y = 80
        
        self.shapes = [
            [[1,1,1,1]],  # I
            [[1,1],[1,1]],  # O
            [[0,1,0],[1,1,1]],  # T
            [[1,0,0],[1,1,1]],  # L
            [[0,0,1],[1,1,1]],  # J
            [[0,1,1],[1,1,0]],  # S
            [[1,1,0],[0,1,1]]   # Z
        ]
        self.colors = [common.Colors.CYAN, common.Colors.YELLOW, common.Colors.MAGENTA, 
                      common.Colors.GREEN, common.Colors.RED, common.Colors.BLUE, common.Colors.LIGHT_RED]
        self.reset()
    
    def reset(self):
        self.grid = [[0 for _ in range(self.grid_width)] for _ in range(self.grid_height)]
        self.current_piece = self.new_piece()
        self.next_piece = self.new_piece()
        self.score = 0
        self.game_over = False
        self.fall_time = 0
        self.fall_speed = 500
    
    def new_piece(self):
        shape_idx = random.randint(0, len(self.shapes)-1)
        return {
            'shape': [row[:] for row in self.shapes[shape_idx]],
            'x': self.grid_width//2 - len(self.shapes[shape_idx][0])//2,
            'y': 0,
            'color': self.colors[shape_idx]
        }
    
    def rotate_piece(self, piece):
        return [list(row) for row in zip(*piece['shape'][::-1])]
    
    def check_collision(self, piece, dx=0, dy=0):
        for y, row in enumerate(piece['shape']):
            for x, cell in enumerate(row):
                if cell:
                    new_x = piece['x'] + x + dx
                    new_y = piece['y'] + y + dy
                    if (new_x < 0 or new_x >= self.grid_width or
                        new_y >= self.grid_height or
                        (new_y >= 0 and self.grid[new_y][new_x])):
                        return True
        return False
    
    def merge_piece(self):
        for y, row in enumerate(self.current_piece['shape']):
            for x, cell in enumerate(row):
                if cell:
                    grid_y = self.current_piece['y'] + y
                    grid_x = self.current_piece['x'] + x
                    if 0 <= grid_y < self.grid_height:
                        self.grid[grid_y][grid_x] = self.current_piece['color']
        
        lines_cleared = 0
        y = self.grid_height - 1
        while y >= 0:
            if all(self.grid[y]):
                del self.grid[y]
                self.grid.insert(0, [0 for _ in range(self.grid_width)])
                lines_cleared += 1
            else:
                y -= 1
        
        self.score += lines_cleared * 100 * lines_cleared
        
        self.current_piece = self.next_piece
        self.next_piece = self.new_piece()
        
        if self.check_collision(self.current_piece):
            self.game_over = True
    
    def update(self):
        if self.game_over:
            return
        
        current_time = pygame.time.get_ticks()
        if current_time - self.fall_time > self.fall_speed:
            if not self.check_collision(self.current_piece, dy=1):
                self.current_piece['y'] += 1
            else:
                self.merge_piece()
            self.fall_time = current_time
    
    def draw(self):
        common.screen.fill(common.Colors.BLACK)
        
        for y in range(self.grid_height):
            for x in range(self.grid_width):
                rect = pygame.Rect(self.grid_x + x*self.cell_size,
                                 self.grid_y + y*self.cell_size,
                                 self.cell_size-2, self.cell_size-2)
                if self.grid[y][x]:
                    pygame.draw.rect(common.screen, self.grid[y][x], rect)
                pygame.draw.rect(common.screen, common.Colors.DARK_GRAY, rect, 1)
        
        if self.current_piece:
            for y, row in enumerate(self.current_piece['shape']):
                for x, cell in enumerate(row):
                    if cell:
                        rect = pygame.Rect(self.grid_x + (self.current_piece['x'] + x)*self.cell_size,
                                         self.grid_y + (self.current_piece['y'] + y)*self.cell_size,
                                         self.cell_size-2, self.cell_size-2)
                        pygame.draw.rect(common.screen, self.current_piece['color'], rect)
        
        next_text = common.font_small.render("NEXT", True, common.Colors.WHITE)
        common.screen.blit(next_text, (self.grid_x + self.grid_width*self.cell_size + 30, 150))
        
        if self.next_piece:
            for y, row in enumerate(self.next_piece['shape']):
                for x, cell in enumerate(row):
                    if cell:
                        rect = pygame.Rect(self.grid_x + self.grid_width*self.cell_size + 30 + x*30,
                                         200 + y*30, 28, 28)
                        pygame.draw.rect(common.screen, self.next_piece['color'], rect)
        
        self.draw_hud()
        
        if self.game_over:
            self.draw_game_over()
        
        common.RetroEffects.draw_scanlines(common.screen)
    
    def handle_input(self, event):
        result = super().handle_input(event)
        if result: return result
        
        if event.type == pygame.KEYDOWN and not self.game_over:
            if event.key == pygame.K_LEFT:
                if not self.check_collision(self.current_piece, dx=-1):
                    self.current_piece['x'] -= 1
            elif event.key == pygame.K_RIGHT:
                if not self.check_collision(self.current_piece, dx=1):
                    self.current_piece['x'] += 1
            elif event.key == pygame.K_UP:
                rotated = self.rotate_piece(self.current_piece)
                old_shape = self.current_piece['shape']
                self.current_piece['shape'] = rotated
                if self.check_collision(self.current_piece):
                    self.current_piece['shape'] = old_shape
            elif event.key == pygame.K_DOWN:
                if not self.check_collision(self.current_piece, dy=1):
                    self.current_piece['y'] += 1