import pygame
import common 

class RetroTicTacToe(common.RetroGame):
    def __init__(self):
        super().__init__("КРЕСТИКИ НОЛИКИ", common.Colors.LIGHT_BLUE, show_lives=False, show_highscore=False)
        self.cell_size = 150
        self.board_x = (common.SCREEN_WIDTH - self.cell_size * 3) // 2
        self.board_y = 150
        self.reset()
        
    def reset(self):
        self.board = [['' for _ in range(3)] for _ in range(3)]
        self.current_player = 'X'
        self.game_over = False
        self.winner = None
        self.score = 0
        
    def check_winner(self):
        for row in self.board:
            if row[0] == row[1] == row[2] != '':
                return row[0]
        
        for col in range(3):
            if self.board[0][col] == self.board[1][col] == self.board[2][col] != '':
                return self.board[0][col]
        
        if self.board[0][0] == self.board[1][1] == self.board[2][2] != '':
            return self.board[0][0]
        if self.board[0][2] == self.board[1][1] == self.board[2][0] != '':
            return self.board[0][2]
        
        if all(self.board[r][c] != '' for r in range(3) for c in range(3)):
            return 'draw'
        
        return None
    
    def update(self):
        winner = self.check_winner()
        if winner:
            self.game_over = True
            self.winner = winner
            if winner == 'X':
                self.score += 100
            elif winner == 'O':
                self.score += 50
    
    def draw(self):
        common.screen.fill(common.Colors.BLACK)
        
        for i in range(1, 3):
            x = self.board_x + i * self.cell_size
            pygame.draw.line(common.screen, common.Colors.WHITE, (x, self.board_y), 
                           (x, self.board_y + self.cell_size * 3), 3)
            y = self.board_y + i * self.cell_size
            pygame.draw.line(common.screen, common.Colors.WHITE, (self.board_x, y), 
                           (self.board_x + self.cell_size * 3, y), 3)
        
        for row in range(3):
            for col in range(3):
                x = self.board_x + col * self.cell_size + self.cell_size//2
                y = self.board_y + row * self.cell_size + self.cell_size//2
                
                if self.board[row][col] == 'X':
                    pygame.draw.line(common.screen, common.Colors.RED, (x - 40, y - 40), (x + 40, y + 40), 5)
                    pygame.draw.line(common.screen, common.Colors.RED, (x + 40, y - 40), (x - 40, y + 40), 5)
                elif self.board[row][col] == 'O':
                    pygame.draw.circle(common.screen, common.Colors.BLUE, (x, y), 50, 5)
        
        if not self.game_over:
            player_text = common.font_medium.render(f"PLAYER {self.current_player}", True, self.color)
            player_rect = player_text.get_rect(center=(common.SCREEN_WIDTH//2, 600))
            common.screen.blit(player_text, player_rect)
        else:
            if self.winner == 'draw':
                result_text = common.font_large.render("DRAW!", True, common.Colors.YELLOW)
            else:
                result_text = common.font_large.render(f"{self.winner} WINS!", True, common.Colors.GREEN)
            result_rect = result_text.get_rect(center=(common.SCREEN_WIDTH//2, 600))
            common.screen.blit(result_text, result_rect)
        
        self.draw_hud()
        
        if self.game_over:
            overlay = pygame.Surface((common.SCREEN_WIDTH, common.SCREEN_HEIGHT))
            overlay.set_alpha(128)
            overlay.fill(common.Colors.BLACK)
            common.screen.blit(overlay, (0, 0))
        
        common.RetroEffects.draw_scanlines(common.screen)
    
    def handle_input(self, event):
        result = super().handle_input(event)
        if result: return result
        
        if event.type == pygame.MOUSEBUTTONDOWN and not self.game_over:
            mouse_x, mouse_y = event.pos
            if (self.board_x <= mouse_x <= self.board_x + self.cell_size * 3 and
                self.board_y <= mouse_y <= self.board_y + self.cell_size * 3):
                col = (mouse_x - self.board_x) // self.cell_size
                row = (mouse_y - self.board_y) // self.cell_size
                if 0 <= row < 3 and 0 <= col < 3 and self.board[row][col] == '':
                    self.board[row][col] = self.current_player
                    self.current_player = 'O' if self.current_player == 'X' else 'X'